'use strict';

// Select the required HTML elements.
const nameForm = document.getElementById('name-form');
const nameInput = document.getElementById('name');
const errorMessage = document.getElementById('error');
const gate = document.getElementById('gate');
const site = document.getElementById('site');

const canvas = document.getElementById('confetti');
const ctx = canvas.getContext('2d');

let pieces = [];
let animationRunning = false;

// Unlock the page when the visitor enters Numan.
nameForm.addEventListener('submit', function (event) {
  event.preventDefault();

  const enteredName = nameInput.value.trim().toLowerCase();

  if (enteredName === 'numan') {
    errorMessage.textContent = '';
    gate.classList.add('hidden');
    site.classList.remove('hidden');
    celebrate();
  } else {
    errorMessage.textContent =
      'This surprise is specially made for Numan. Please enter "Numan".';
    nameInput.focus();
  }
});

// Keep the canvas sharp on normal and high-density screens.
function resizeCanvas() {
  const pixelRatio = window.devicePixelRatio || 1;

  canvas.width = Math.round(window.innerWidth * pixelRatio);
  canvas.height = Math.round(window.innerHeight * pixelRatio);

  ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
}

window.addEventListener('resize', resizeCanvas);
resizeCanvas();

// Create a new burst of confetti.
function celebrate() {
  const colors = ['#ffd98a', '#ff8db5', '#ffffff', '#8edcff', '#c4a7ff'];

  for (let i = 0; i < 170; i += 1) {
    pieces.push({
      x: window.innerWidth / 2 + (Math.random() - 0.5) * 180,
      y: window.innerHeight * 0.48,
      vx: (Math.random() - 0.5) * 9,
      vy: Math.random() * -10 - 3,
      gravity: 0.16,
      size: Math.random() * 7 + 3,
      rotation: Math.random() * 6,
      color: colors[i % colors.length],
      life: 150
    });
  }

  if (!animationRunning) {
    animationRunning = true;
    animateConfetti();
  }
}

// Animate confetti until every piece has disappeared.
function animateConfetti() {
  ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);

  pieces = pieces.filter(function (piece) {
    return piece.life > 0 && piece.y < window.innerHeight + 30;
  });

  pieces.forEach(function (piece) {
    piece.life -= 1;
    piece.vy += piece.gravity;
    piece.x += piece.vx;
    piece.y += piece.vy;
    piece.rotation += 0.12;

    ctx.save();
    ctx.translate(piece.x, piece.y);
    ctx.rotate(piece.rotation);
    ctx.fillStyle = piece.color;
    ctx.fillRect(
      -piece.size / 2,
      -piece.size / 2,
      piece.size,
      piece.size * 0.65
    );
    ctx.restore();
  });

  if (pieces.length > 0) {
    window.requestAnimationFrame(animateConfetti);
  } else {
    animationRunning = false;
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
  }
}

// Make both celebration buttons work.
document.querySelectorAll('[data-celebrate]').forEach(function (button) {
  button.addEventListener('click', celebrate);
});
